//
//  TT_CX3Cell.h
//  ChuXingViewDemo
//
//  Created by Dev on 2017/6/16.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "TT_CXCollectionViewCell.h"

@interface TT_CX3Cell : TT_CXCollectionViewCell

@end
