//
//  CustomViewController.h
//  ChuXingViewDemo
//
//  Created by Dev on 2017/6/20.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "TT_CXBaseViewController.h"

@interface CustomViewController : TT_CXBaseViewController

@end
