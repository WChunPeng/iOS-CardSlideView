//
//  CustomViewController.m
//  ChuXingViewDemo
//
//  Created by Dev on 2017/6/20.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "CustomViewController.h"
#import "TT_CX1Cell.h"
#import "TT_CX2Cell.h"
#import "TT_CX3Cell.h"

@interface CustomViewController ()<Cell2Deleagte>

@end

@implementation CustomViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    /*
     创建假数据
     */
    
    NSArray *array1 = [NSArray arrayWithObjects:@"2017.02.12",@"外出办材料",@"ssrgerg",@"王师傅4",@"无备注",@"2017.02.12",@"外出办材料",@"王sgdsfhgdsf",@"王师傅4",@"无备注", @"2017.03.12",@"又一次外出办材料",@"王春鹏",@"王师傅4",@"这次有备注",nil];
    
    NSArray *array2 = [NSArray arrayWithObjects:@"2017.03.12",@"又一次外出办材料",@"王fdsf",@"王师傅4",@"这次有备注", nil];
    
    NSArray *array3 = [NSArray arrayWithObjects:@"2017.02.12师傅",@"外出办材料虽然法国",@"dfj是法国人",@"二夫人王师傅4",@"无备注了撒啊", nil];
    
    self.dataSourceArray = [NSMutableArray arrayWithObjects:array1,array2,array3, nil];
    
    // 刷新
    [self.myCollectionView reloadData];

}

/*
  重写基类 注册cell的方法，并刷新collectionview
 */

- (void)registCollectionViewCell
{
    /*
     注册cell，页面有几种cell样式，就注册几个cell，注册的cell都需继承与TT_CXCollectionViewCell 这个基类cell
     */
    UINib *cellNib = [UINib nibWithNibName:@"TT_CX1Cell" bundle:nil];
    [self.myCollectionView  registerNib:cellNib forCellWithReuseIdentifier:@"cell1"];
    
    UINib *cellNib2 = [UINib nibWithNibName:@"TT_CX2Cell" bundle:nil];
    [self.myCollectionView  registerNib:cellNib2 forCellWithReuseIdentifier:@"cell2"];
    
    UINib *cellNib3 = [UINib nibWithNibName:@"TT_CX3Cell" bundle:nil];
    [self.myCollectionView  registerNib:cellNib3 forCellWithReuseIdentifier:@"cell3"];
    
}

/*
 重写基类 collectionview 的dataSource方法，即总共几张卡片和每张卡片的内容
 */
#pragma mark cell的数量

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.dataSourceArray.count;
}

#pragma mark cell的视图

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0) {
        NSString *cellIdentifier = @"cell1";
        
        TT_CX1Cell *cell1 = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
        cell1.dataSource = self.dataSourceArray[0];
        return cell1;
    }
    
    else if (indexPath.row==1) {
        NSString *cellIdentifier = @"cell2";
        
        TT_CX2Cell *cell2 = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
        cell2.dataSource = self.dataSourceArray[1];
        cell2.delegate = self;
        return cell2;
    }
    
    else  {
        
        NSString *cellIdentifier = @"cell3";
        
        TT_CX3Cell *cell3 = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
        
        return cell3;
        
    }
}

#pragma mark 自定义代理响应事件
// 举例：

- (void)selectButtonWithButton:(UIButton *)btn
{
    NSLog(@"点击了按钮");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
