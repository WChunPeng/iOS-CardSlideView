//
//  ViewController.m
//  ChuXingViewDemo
//
//  Created by Dev on 2017/6/15.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "ViewController.h"
#import "TT_CX1Cell.h"
#import "TT_CX2Cell.h"
#import "TT_CX3Cell.h"

#import "TT_CXCollectionViewFlowLayout.h"

#define SCREENWITH   [UIScreen mainScreen].bounds.size.width
#define SCREENHEIGHT   [UIScreen mainScreen].bounds.size.height

@interface ViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,Cell2Deleagte>
{
    /*
     数据源数组
     */
    NSMutableArray *_dataSourceArray;
    
    /*
     卡片试图
     */
    UICollectionView *_myCollectionView;
}
@property (weak, nonatomic) IBOutlet UIView *titleBGView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    /*
     设置导航条
     */
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:52.0/255.0 green:170.0/255.0 blue:220.0/255.0 alpha:1];
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    //下面两行代码是隐藏导航条下面的线
    [self.navigationController.navigationBar setBackgroundImage:[[UIImage alloc] init]
                       forBarPosition:UIBarPositionAny
                           barMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    self.navigationController.navigationBar.translucent = NO;
    
    /*
     设置背景颜色
     */
    self.titleBGView.backgroundColor = [UIColor colorWithRed:52.0/255.0 green:170.0/255.0 blue:220.0/255.0 alpha:1];
    self.view.backgroundColor = [UIColor colorWithRed:247.0/255.0 green:247.0/255.0 blue:247.0/255.0 alpha:1];

    /*
     创建假数据
     */
    
    NSArray *array1 = [NSArray arrayWithObjects:@"2017.02.12",@"外出办材料",@"王春鹏",@"王师傅4",@"无备注",@"2017.02.12",@"外出办材料",@"王春鹏",@"王师傅4",@"无备注", @"2017.03.12",@"又一次外出办材料",@"王春鹏",@"王师傅4",@"这次有备注",nil];
    
    NSArray *array2 = [NSArray arrayWithObjects:@"2017.03.12",@"又一次外出办材料",@"王春鹏",@"王师傅4",@"这次有备注", nil];

    NSArray *array3 = [NSArray arrayWithObjects:@"2017.02.12师傅",@"外出办材料虽然法国",@"王春鹏是法国人",@"二夫人王师傅4",@"无备注了撒啊", nil];
    
    _dataSourceArray = [NSMutableArray arrayWithObjects:array1,array2,array3, nil];
    
    
    /*
     自定义collectionview的layout
     */
    
    TT_CXCollectionViewFlowLayout *layout = [[TT_CXCollectionViewFlowLayout alloc] init];
    
    layout.isPagingEnabled = YES;
    
    CGFloat collectionHeight ;
    
    if (SCREENWITH == 320) {
        collectionHeight = SCREENHEIGHT*0.75;
    }else if (SCREENWITH == 375) {
        collectionHeight = SCREENHEIGHT*0.78;
    }else{
        collectionHeight = SCREENHEIGHT*0.79;
    }
    
    /*
     新建自定义出行试图
     */
    //collectionViewCell添加layout
    _myCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0,10, SCREENWITH,collectionHeight) collectionViewLayout:layout];
    _myCollectionView.backgroundColor = [UIColor clearColor];
    _myCollectionView.showsHorizontalScrollIndicator = NO;
    
    
    _myCollectionView.delegate = self;
    _myCollectionView.dataSource = self;

    [self.view addSubview:_myCollectionView];
    
    /*
     注册cell，页面有几种cell样式，就注册几个cell，注册的cell都需继承与TT_CXCollectionViewCell 这个基类cell
     */
    UINib *cellNib = [UINib nibWithNibName:@"TT_CX1Cell" bundle:nil];
    [_myCollectionView  registerNib:cellNib forCellWithReuseIdentifier:@"cell1"];
    
    UINib *cellNib2 = [UINib nibWithNibName:@"TT_CX2Cell" bundle:nil];
    [_myCollectionView  registerNib:cellNib2 forCellWithReuseIdentifier:@"cell2"];
    
    UINib *cellNib3 = [UINib nibWithNibName:@"TT_CX3Cell" bundle:nil];
    [_myCollectionView  registerNib:cellNib3 forCellWithReuseIdentifier:@"cell3"];

    // 刷新
    [_myCollectionView reloadData];
    
}

#pragma mark 代理响应时间

- (void)selectButtonWithButton:(UIButton *)btn
{
    NSLog(@"点击了按钮");
}

#pragma mark cell的数量

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _dataSourceArray.count;
}

#pragma mark cell的视图

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0) {
        NSString *cellIdentifier = @"cell1";
        
        TT_CX1Cell *cell1 = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
        cell1.dataSource = _dataSourceArray[0];
        return cell1;
    }
    
    else if (indexPath.row==1) {
        NSString *cellIdentifier = @"cell2";
        
        TT_CX2Cell *cell2 = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
        cell2.dataSource = _dataSourceArray[1];
        cell2.delegate = self;
        return cell2;
    }
    
    else  {
        
        NSString *cellIdentifier = @"cell3";
        
        TT_CX3Cell *cell3 = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
        
        return cell3;
        
     }
}

#pragma mark cell的大小

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(SCREENWITH-36, collectionView.frame.size.height);
}

#pragma mark 此方法必须要加，针对解决collectionview滚动时，cell会消失的问题

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
