//
//  TT_CX2Cell.m
//  ChuXingViewDemo
//
//  Created by Dev on 2017/6/15.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "TT_CX2Cell.h"

@implementation TT_CX2Cell

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)setup
{
    self.nameTF.text = self.dataSource[0];
    self.titleTF.text = self.dataSource[1];
    self.timeTF.text =self.dataSource[2];
    self.followTF.text = self.dataSource[3];
    self.markTF.text = self.dataSource[4];
}

- (IBAction)buttonClick:(UIButton *)sender
{
    [self.delegate selectButtonWithButton:sender];
}

@end
