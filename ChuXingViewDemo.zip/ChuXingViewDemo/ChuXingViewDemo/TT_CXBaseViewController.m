//
//  TT_CXBaseViewController.m
//  ChuXingViewDemo
//
//  Created by Dev on 2017/6/20.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "TT_CXBaseViewController.h"
#import "TT_CXCollectionViewFlowLayout.h"

#define SCREENWITH   [UIScreen mainScreen].bounds.size.width
#define SCREENHEIGHT   [UIScreen mainScreen].bounds.size.height

@interface TT_CXBaseViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (strong ,nonatomic) UIView *titleBGView;

@end

@implementation TT_CXBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationController.navigationBar.translucent = NO;

    self.view.backgroundColor = [UIColor colorWithRed:247.0/255.0 green:247.0/255.0 blue:247.0/255.0 alpha:1];

    /*
     设置导航条下的view
     */
    self.titleBGView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREENWITH, 86)];
    self.titleBGView.backgroundColor = [UIColor colorWithRed:52.0/255.0 green:170.0/255.0 blue:220.0/255.0 alpha:1];
    [self.view addSubview:self.titleBGView];
    
    /*
     自定义collectionview的layout
     */
    
    TT_CXCollectionViewFlowLayout *layout = [[TT_CXCollectionViewFlowLayout alloc] init];
    
    layout.isPagingEnabled = YES;
    
    CGFloat collectionHeight ;
    
    if (SCREENWITH == 320) {
        collectionHeight = SCREENHEIGHT*0.75;
    }else if (SCREENWITH == 375) {
        collectionHeight = SCREENHEIGHT*0.78;
    }else{
        collectionHeight = SCREENHEIGHT*0.79;
    }
    
    /*
     新建自定义出行试图
     */
    //collectionViewCell添加layout
    
    _myCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0,10, SCREENWITH,collectionHeight) collectionViewLayout:layout];
    _myCollectionView.backgroundColor = [UIColor clearColor];
    _myCollectionView.showsHorizontalScrollIndicator = NO;
    
    _myCollectionView.delegate = self;
    _myCollectionView.dataSource = self;
    
    [self.view addSubview:_myCollectionView];

    [self registCollectionViewCell];
}

/*
 重写基类 注册cell的方法，并刷新collectionview
 */
- (void)registCollectionViewCell
{
    
}

#pragma mark cell的数量

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _dataSourceArray.count;
}

#pragma mark cell的视图

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return nil;
}

#pragma mark cell的大小

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(SCREENWITH-36, collectionView.frame.size.height);
}

#pragma mark 此方法必须要加，针对解决collectionview滚动时，cell会消失的问题

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
