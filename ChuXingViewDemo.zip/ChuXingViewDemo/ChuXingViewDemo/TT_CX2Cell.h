//
//  TT_CX2Cell.h
//  ChuXingViewDemo
//
//  Created by Dev on 2017/6/15.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "TT_CXCollectionViewCell.h"

@protocol Cell2Deleagte <NSObject>
//点击按钮
-(void)selectButtonWithButton:(UIButton *)btn;


@end

@interface TT_CX2Cell : TT_CXCollectionViewCell
@property (weak, nonatomic) IBOutlet UITextField *timeTF;
@property (weak, nonatomic) IBOutlet UITextField *titleTF;
@property (weak, nonatomic) IBOutlet UITextField *nameTF;
@property (weak, nonatomic) IBOutlet UITextField *followTF;
@property (weak, nonatomic) IBOutlet UITextField *markTF;
@property (assign,nonatomic) id<Cell2Deleagte> delegate;

@end
