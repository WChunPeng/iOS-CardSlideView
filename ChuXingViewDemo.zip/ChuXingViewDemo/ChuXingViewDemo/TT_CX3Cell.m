//
//  TT_CX3Cell.m
//  ChuXingViewDemo
//
//  Created by Dev on 2017/6/16.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "TT_CX3Cell.h"

@implementation TT_CX3Cell

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
