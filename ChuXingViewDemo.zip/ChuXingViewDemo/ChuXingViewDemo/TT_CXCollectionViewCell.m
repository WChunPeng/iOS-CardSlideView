//
//  TT_CXCollectionViewCell.m
//  CardSlide
//
//  Created by Dev on 2017/6/15.
//  Copyright © 2017年 DavidWang. All rights reserved.
//

#import "TT_CXCollectionViewCell.h"

@implementation TT_CXCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.layer.cornerRadius = 30.0f;
//    self.layer.borderColor=[UIColor greenColor].CGColor;
//    self.layerborderWidth=0.2;
}

- (void)setDataSource:(id )dataSource {
    if (_dataSource != dataSource) {
        _dataSource = dataSource;
        [self setup];
        [self layoutIfNeeded];
    }
}

- (void)setup {}

@end
