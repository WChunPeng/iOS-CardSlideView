//
//  TT_CX1Cell.h
//  ChuXingViewDemo
//
//  Created by Dev on 2017/6/15.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "TT_CXCollectionViewCell.h"

@interface TT_CX1Cell : TT_CXCollectionViewCell
@property (weak, nonatomic) IBOutlet UITableView *myTableView;

@end
