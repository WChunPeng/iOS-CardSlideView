//
//  TT_CXBaseViewController.h
//  ChuXingViewDemo
//
//  Created by Dev on 2017/6/20.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TT_CXBaseViewController : UIViewController

/*
 卡片试图
 */
@property (strong, nonatomic) UICollectionView *myCollectionView;
/*
 数据源数组
 */
@property (strong, nonatomic) NSMutableArray *dataSourceArray;

/*
 重写基类 注册cell的方法，并刷新collectionview
 */
- (void)registCollectionViewCell;

@end
