//
//  TT_CXCollectionViewFlowLayout.h
//  ChuXingViewDemo
//
//  Created by Dev on 2017/6/15.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TT_CXCollectionViewFlowLayout : UICollectionViewFlowLayout

@property CGFloat move_x;

/*
 当设置成yes时，滑动只能一页一页进行
 当设置成no时，正常scrollview滑动，
 */
@property BOOL isPagingEnabled;

-(void)setPagingEnabled:(BOOL)isPagingEnabled;

@end
