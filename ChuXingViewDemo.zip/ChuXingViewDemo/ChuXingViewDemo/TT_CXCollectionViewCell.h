//
//  TT_CXCollectionViewCell.h
//  CardSlide
//
//  Created by Dev on 2017/6/15.
//  Copyright © 2017年 DavidWang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TT_CXCollectionViewCell : UICollectionViewCell

/*
 基类cell的数据源，可以是数组或字典
 */
@property (nonatomic, strong) id dataSource;

/*
 子类cell可以重写此方法
 */
- (void)setup;

@end
