//
//  TT_CX1Cell.m
//  ChuXingViewDemo
//
//  Created by Dev on 2017/6/15.
//  Copyright © 2017年 Dev. All rights reserved.
//

#import "TT_CX1Cell.h"

@interface TT_CX1Cell()<UITableViewDelegate,UITableViewDataSource>

{
    NSMutableArray *dataArray;
}
@end
@implementation TT_CX1Cell

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


- (void)setup
{
    dataArray = [NSMutableArray arrayWithArray:self.dataSource];
    self.myTableView.delegate = self;
    self.myTableView.dataSource =self;
    [self.myTableView reloadData];
}

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return  1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"SHCartTableViewCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc]init];
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    }
    cell.textLabel.text = dataArray[indexPath.row];
    
    return cell;
}

- (IBAction)buttonClick:(UIButton *)sender
{
    
}

@end
